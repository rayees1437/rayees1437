# Data Analyst Portfolio Project Repository

This Repository will hold all of the code and queries from the Portfolio Projects we create.

Please feel free to take these and run with them. Make them your own and find you own insights

I really do hope this is helpful and helps you land that dream job! :D
